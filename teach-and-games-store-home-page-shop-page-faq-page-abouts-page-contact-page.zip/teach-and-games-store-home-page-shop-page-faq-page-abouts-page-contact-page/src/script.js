// ─── Products Data ───────────────────────────────────────────
const products = [
  {
    tag: "Hot", tagColor: "#ff8800",
    name: "RGB Gaming Keyboard",
    price: "£95.89",
    img: "https://i.dell.com/is/image/DellContent/content/dam/images/products/electronics-and-accessories/dell/keyboards/aw510k/aw510k-ckb-90000td-gy.psd?fmt=png-alpha&pscan=auto&scl=1&hei=804&wid=1106&qlt=100,1&resMode=sharp2&size=1106,804&chrss=full"
  },
  {
    tag: "New", tagColor: "#cc44ff",
    name: "Glacienne Ryzen 7 RTX 5090 Gaming PC",
    price: "£6390.78",
    img: "https://cdn.chillblast.com/cdn-cgi/image/width=2000,quality=95/images/shopblocks/CB-GAM-CORE-017_01.png"
  },
  {
    tag: "Sale", tagColor: "#ff4444",
    name: "Minifire 24 Inch Gaming Monitor",
    price: "£85.79",
    img: "https://m.media-amazon.com/images/I/81X426h2fpL._AC_SX679_.jpg"
  },
  {
    tag: "New", tagColor: "#cc44ff",
    name: "Razer Iskur V2 X NewGen",
    price: "£124.99",
    img: "https://assets3.razerzone.com/tZy6DFnalu5vOqIFJKakf-Kgg8A=/300x300/https%3A%2F%2Fmedias-p1.phoenix.razer.com%2Fsys-master-phoenix-images-container%2Fhf8%2Fh3a%2F10009902415902%2Fiskur-v2-x-newgen-blackgreen-500x500.png"
  },
  {
    tag: "Hot", tagColor: "#ff8800",
    name: "Razer DeathAdder V4 Pro",
    price: "£185.79",
    img: "https://assets3.razerzone.com/VUNbt5Gwmvfi2_6mTTU3ztgmS5g=/300x300/https%3A%2F%2Fmedias-p1.phoenix.razer.com%2Fsys-master-phoenix-images-container%2Fhac%2Fhb9%2F10023907524638%2Fdeathadder-v4-pro-niko-500x500.png"
  },
];

// ─── Carousel State ──────────────────────────────────────────
let currentIndex = 0;
let autoScroll = null;
let isAnimating = false;

// ─── Build Carousel ──────────────────────────────────────────
function buildCarousel() {
  const track = document.querySelector(".carousel-track");
  if (!track) return;

  // Duplicate cards before and after for infinite loop effect
  const all = [...products, ...products, ...products];

  track.innerHTML = all.map((p, i) => `
    <div class="carousel-card" data-index="${i % products.length}">
      <img src="${p.img}" alt="${p.name}" class="product-img"/>
      <span class="tag" style="background:${p.tagColor}">${p.tag}</span>
      <h4>${p.name}</h4>
      <div class="price">${p.price}</div>
      <button class="add-btn" onclick="addToCart('${p.name}', '${p.price}')">
        Add to Cart
      </button>
    </div>
  `).join("");

  // Start in the middle set so we can loop both ways
  currentIndex = products.length;
  updateCarousel(false);
}

// ─── Move Carousel ───────────────────────────────────────────
function updateCarousel(animate = true) {
  const track = document.querySelector(".carousel-track");
  if (!track) return;

  const card = track.querySelector(".carousel-card");
  if (!card) return;

  const cardWidth = card.offsetWidth + 16;
  track.style.transition = animate ? "transform 0.5s cubic-bezier(0.4,0,0.2,1)" : "none";
  track.style.transform = `translateX(-${currentIndex * cardWidth}px)`;

  updateDots();
}

// ─── Infinite Loop Reset ─────────────────────────────────────
function onTransitionEnd() {
  const track = document.querySelector(".carousel-track");
  if (!track) return;

  const total = products.length * 3;

  if (currentIndex >= products.length * 2) {
    currentIndex = products.length;
    updateCarousel(false);
  }
  if (currentIndex <= 0) {
    currentIndex = products.length;
    updateCarousel(false);
  }

  isAnimating = false;
}

// ─── Next / Prev ─────────────────────────────────────────────
function nextSlide() {
  if (isAnimating) return;
  isAnimating = true;
  currentIndex++;
  updateCarousel(true);
  resetAutoScroll();
}

function prevSlide() {
  if (isAnimating) return;
  isAnimating = true;
  currentIndex--;
  updateCarousel(true);
  resetAutoScroll();
}

// ─── Dots ────────────────────────────────────────────────────
function buildDots() {
  const dotsEl = document.querySelector(".carousel-dots");
  if (!dotsEl) return;

  dotsEl.innerHTML = products.map((_, i) => `
    <button class="dot ${i === 0 ? "active" : ""}" onclick="goToSlide(${i})"></button>
  `).join("");
}

function updateDots() {
  const dots = document.querySelectorAll(".dot");
  const realIndex = (currentIndex - products.length + products.length) % products.length;
  dots.forEach((d, i) => d.classList.toggle("active", i === realIndex));
}

function goToSlide(index) {
  if (isAnimating) return;
  isAnimating = true;
  currentIndex = products.length + index;
  updateCarousel(true);
  resetAutoScroll();
}

// ─── Auto Scroll ─────────────────────────────────────────────
function startAutoScroll() {
  autoScroll = setInterval(() => {
    if (!isAnimating) {
      isAnimating = true;
      currentIndex++;
      updateCarousel(true);
    }
  }, 3000);
}

function resetAutoScroll() {
  clearInterval(autoScroll);
  startAutoScroll();
}

// ─── Touch / Swipe ───────────────────────────────────────────
let touchStartX = 0;

function initTouch() {
  const wrapper = document.querySelector(".carousel-wrapper");
  if (!wrapper) return;

  wrapper.addEventListener("touchstart", e => {
    touchStartX = e.touches[0].clientX;
  });

  wrapper.addEventListener("touchend", e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (diff > 50) nextSlide();
    if (diff < -50) prevSlide();
  });
}

// ─── Init ────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  buildCarousel();
  buildDots();
  startAutoScroll();
  initTouch();

  const track = document.querySelector(".carousel-track");
  if (track) track.addEventListener("transitionend", onTransitionEnd);

  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");
  if (prevBtn) prevBtn.onclick = prevSlide;
  if (nextBtn) nextBtn.onclick = nextSlide;
});

function openLogin() {
  alert("Sign In / Account feature coming soon!");
}