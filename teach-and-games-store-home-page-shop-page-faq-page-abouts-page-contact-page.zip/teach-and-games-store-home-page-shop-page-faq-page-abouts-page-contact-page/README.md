# Teach and Games store | Home page | Shop page | FAQ page | Abouts page | Contact page 

A Pen created on CodePen.

Original URL: [https://codepen.io/Uchiha_code/pen/raWxoda](https://codepen.io/Uchiha_code/pen/raWxoda).

I created LevelUp Games & Tech, an online store designed for gaming PCs, keyboards, monitors, and tech accessories. Before coding, I sketched out each page on paper to make sure the site was easy to navigate and simple to use. The store features a homepage with a product carousel and video, a shop page with prices and details, a working shopping cart, and quick contact options. I used a dark gaming style with purple and cyan accents to give it a modern look. Building this project helped me sharpen my web development skills, and in the future, I plan to add product filtering and a full checkout page.